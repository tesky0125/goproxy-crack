goproxy 正式版 https://git.io/goproxy [ ![CI Releases](https://img.shields.io/github/release/phuslu/goproxy-ci.svg?label=%E6%AF%8F%E6%97%A5%E6%9E%84%E5%BB%BA%E7%89%88)](https://github.com/phuslu/goproxy-ci/releases) [ ![CI Status](https://travis-ci.org/phuslu/goproxy.svg?branch=master)](https://travis-ci.org/phuslu/goproxy/builds) [ ![Google Translate](https://www.gstatic.com/images/branding/product/1x/translate_24dp.png)](https://translate.google.com/translate?hl=en&sl=zh-CN&tl=en&u=https%3A%2F%2Fgithub.com%2Fphuslu%2Fgoproxy)

## 讨论区
* https://github.com/phuslu/goproxy/issues?q=sort:updated-desc+is:open

## 文档
* 简易教程 https://github.com/phuslu/goproxy/blob/wiki/SimpleGuide.md
* 配置介绍 https://github.com/phuslu/goproxy/blob/wiki/ConfigIntroduce.md
* 常见问题 https://github.com/phuslu/goproxy/blob/wiki/FAQ.md
* 编译步骤 https://github.com/phuslu/goproxy/blob/wiki/HowToBuild.md

## 代码
 * goproxy https://github.com/phuslu/goproxy
 * goproxy-gui.exe https://github.com/phuslu/taskbar

## 许可证
 * GPLv2 http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
